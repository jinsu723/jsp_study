package com.learning.app.dto;

import java.util.Date;

public class UserDTO {
    private int userNumber;       // user_number
    private String userId;        // user_id
    private String userPw;        // user_passwd
    private String userNickname;  // user_nickname
    private String userTier;      // user_tier
    private String userPhone;     // user_phone
    private Date userJoinDate;    // user_join_date
    private int userBenCtn;       // user_ben_ctn

    // Getters and Setters
    public int getUserNumber() {
        return userNumber;
    }

    public void setUserNumber(int userNumber) {
        this.userNumber = userNumber;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserPw() {
        return userPw;
    }

    public void setUserPw(String userPw) {
        this.userPw = userPw;
    }

    public String getUserNickname() {
        return userNickname;
    }

    public void setUserNickname(String userNickname) {
        this.userNickname = userNickname;
    }

    public String getUserTier() {
        return userTier;
    }

    public void setUserTier(String userTier) {
        this.userTier = userTier;
    }

    public String getUserPhone() {
        return userPhone;
    }

    public void setUserPhone(String userPhone) {
        this.userPhone = userPhone;
    }

    public Date getUserJoinDate() {
        return userJoinDate;
    }

    public void setUserJoinDate(Date userJoinDate) {
        this.userJoinDate = userJoinDate;
    }

    public int getUserBenCtn() {
        return userBenCtn;
    }

    public void setUserBenCtn(int userBenCtn) {
        this.userBenCtn = userBenCtn;
    }
}
