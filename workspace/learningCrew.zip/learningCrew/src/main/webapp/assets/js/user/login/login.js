/*document.addEventListener("DOMContentLoaded", () => {
    // 숨겨진 태그에서 메시지 가져오기
    const messageElement = document.getElementById("messages");
    if (!messageElement) return; // messageElement가 없을 경우 처리 종료

    const loginMessage = messageElement.getAttribute("data-message") || ""; // 메시지가 없으면 빈 문자열
    const loginError = messageElement.getAttribute("data-error") || ""; // 에러 메시지가 없으면 빈 문자열

    // 메시지가 존재하면 alert로 출력
    if (loginMessage.trim()) {
        alert(loginMessage);
    }
    if (loginError.trim()) {
        alert(loginError);
    }
});*/

/*console.log(loginCheck.loginOkNum);*/